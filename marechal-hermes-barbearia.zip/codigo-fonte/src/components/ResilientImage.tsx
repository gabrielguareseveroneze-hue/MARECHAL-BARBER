import { useState } from 'react';
import { motion } from 'motion/react';
import { Scissors } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  wrapperClassName?: string;
  loading?: 'eager' | 'lazy';
  fetchPriority?: 'high' | 'low' | 'auto';
  animateOnView?: boolean;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  wrapperClassName = 'h-full w-full',
  loading = 'lazy',
  fetchPriority = 'auto',
  animateOnView = true,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-3 bg-surface-elevated p-6 text-center text-ink-secondary ${wrapperClassName} ${className}`}
      >
        <Scissors className="h-7 w-7 text-accent" aria-hidden="true" />
        <span className="font-display text-sm tracking-wide text-ink">{alt}</span>
      </div>
    );
  }

  if (!animateOnView) {
    return (
      <img
        src={src}
        alt={alt}
        loading={loading}
        fetchPriority={fetchPriority}
        decoding="async"
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={className}
      />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 1.05 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
      className={wrapperClassName}
    >
      <img
        src={src}
        alt={alt}
        loading={loading}
        fetchPriority={fetchPriority}
        decoding="async"
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={className}
      />
    </motion.div>
  );
}
