import { BARBERSHOP_INFO, buildWhatsAppUrl } from '../data/barbershop';

const FOOTER_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#barbearia', label: 'Sobre' },
  { href: '#profissionais', label: 'Profissionais' },
  { href: '#avaliacoes', label: 'Avaliações' },
  { href: '#contato', label: 'Contato' },
] as const;

export function Footer() {
  return (
    <footer className="bg-canvas py-16">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 gap-10 border-b border-hairline pb-12 md:grid-cols-12">
          {/* Brand & Info */}
          <div className="md:col-span-5">
            <a
              href="#inicio"
              className="inline-flex items-center gap-4 font-display text-xl font-bold uppercase tracking-wider text-ink"
            >
              <img
                src={BARBERSHOP_INFO.logo}
                alt={`Logo ${BARBERSHOP_INFO.name}`}
                className="h-16 w-16 rounded-sm border border-hairline object-cover shrink-0"
              />
              <span>{BARBERSHOP_INFO.name}</span>
            </a>

            <div className="mt-5 space-y-2 text-sm text-ink-secondary">
              <p>{BARBERSHOP_INFO.address}</p>
              <p className="tabular-nums">Telefone: {BARBERSHOP_INFO.phoneDisplay}</p>
              <p className="tabular-nums">
                WhatsApp:{' '}
                <a
                  href={buildWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-ink underline decoration-hairline underline-offset-4 transition-colors hover:text-accent-bright"
                >
                  {BARBERSHOP_INFO.whatsappDisplay}
                </a>
              </p>
            </div>
          </div>

          {/* Navigation */}
          <div className="md:col-span-4">
            <h3 className="font-display text-sm font-bold uppercase tracking-wider text-ink">
              Navegação
            </h3>
            <nav
              aria-label="Links do rodapé"
              className="mt-4 grid grid-cols-2 gap-3 text-sm text-ink-secondary"
            >
              {FOOTER_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="transition-colors hover:text-ink"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Socials */}
          <div className="md:col-span-3">
            <h3 className="font-display text-sm font-bold uppercase tracking-wider text-ink">
              Redes Sociais
            </h3>
            <div className="mt-4 flex flex-col gap-3 text-sm text-ink-secondary">
              <a
                href={BARBERSHOP_INFO.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors hover:text-accent-bright"
              >
                Instagram
              </a>
              <a
                href={BARBERSHOP_INFO.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors hover:text-accent-bright"
              >
                Facebook
              </a>
              <a
                href={BARBERSHOP_INFO.social.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-colors hover:text-accent-bright"
              >
                TikTok
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-3 text-xs text-ink-muted sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {BARBERSHOP_INFO.name}. Todos os direitos reservados.
          </p>
          <p>{BARBERSHOP_INFO.cityState}</p>
        </div>
      </div>
    </footer>
  );
}
