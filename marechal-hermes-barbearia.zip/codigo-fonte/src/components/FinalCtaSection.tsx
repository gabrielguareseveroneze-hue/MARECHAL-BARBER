import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { FINAL_CTA_MEDIA, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function FinalCtaSection() {
  const whatsappHref = buildWhatsAppUrl();

  return (
    <section className="border-b border-hairline bg-surface py-24 sm:py-28 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-center gap-10 overflow-hidden rounded-sm border border-hairline bg-canvas lg:grid-cols-12">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="p-8 sm:p-12 lg:col-span-7 lg:p-14"
          >
            <h2
              className="font-display font-bold uppercase tracking-tight text-ink"
              style={{
                fontSize: 'clamp(2.25rem, 4.4vw, 3.6rem)',
                lineHeight: 1.02,
                textWrap: 'balance',
              }}
            >
              SEU PRÓXIMO CORTE JÁ TEM HORA MARCADA?
            </h2>

            <p className="mt-5 max-w-lg text-base leading-relaxed text-ink-secondary">
              Não deixe para depois. Escolha seu serviço e agende seu horário.
            </p>

            <div className="mt-9">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-14 w-full sm:w-auto items-center justify-center gap-3 rounded-sm bg-accent px-8 py-4 text-sm font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <span>AGENDAR MEU HORÁRIO</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          <div className="relative aspect-[16/10] lg:aspect-auto lg:h-full lg:min-h-[380px] lg:col-span-5 overflow-hidden bg-surface-elevated">
            <ResilientImage
              src={FINAL_CTA_MEDIA.image}
              alt={FINAL_CTA_MEDIA.alt}
              className="h-full w-full object-cover object-center"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-gradient-to-r from-canvas via-canvas/20 to-transparent"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
