import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import { SERVICES, buildWhatsAppUrl, type BarberService } from '../data/barbershop';

const STEPS = [
  {
    number: '01',
    title: 'Escolha o serviço',
    detail: 'Selecione o corte, barba ou atendimento completo que você precisa hoje.',
  },
  {
    number: '02',
    title: 'Entre em contato pelo WhatsApp',
    detail: 'Nossa mensagem já vai preenchida com o serviço escolhido.',
  },
  {
    number: '03',
    title: 'Escolha o melhor horário',
    detail: 'Alinhamos com você o período mais confortável na agenda.',
  },
  {
    number: '04',
    title: 'Pronto. Seu horário está reservado.',
    detail: 'É só chegar no horário combinado e aproveitar a experiência.',
  },
] as const;

export function BookingFlowSection() {
  const [selectedId, setSelectedId] = useState<BarberService['id']>('corte');
  const activeService = SERVICES.find((s) => s.id === selectedId) ?? SERVICES[0];

  return (
    <section
      id="agendamento"
      className="border-b border-hairline bg-canvas py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-start gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Headline, Quick Service Selector, Big WhatsApp CTA */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <h2
              className="font-display font-bold uppercase tracking-tight text-ink"
              style={{
                fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
                lineHeight: 1.02,
                textWrap: 'balance',
              }}
            >
              AGENDE SEU HORÁRIO
            </h2>

            <p className="mt-5 max-w-lg text-base leading-relaxed text-ink-secondary sm:text-lg">
              Escolha o serviço, fale com nossa equipe e garanta seu horário.
            </p>

            {/* Interactive Service Selector */}
            <div className="mt-8">
              <p className="text-xs font-semibold text-ink-secondary">
                Selecione o serviço desejado:
              </p>
              <div
                role="radiogroup"
                aria-label="Selecionar serviço para agendamento"
                className="mt-3 flex flex-wrap gap-2"
              >
                {SERVICES.map((service) => {
                  const isActive = service.id === selectedId;
                  return (
                    <button
                      key={service.id}
                      type="button"
                      role="radio"
                      aria-checked={isActive}
                      onClick={() => setSelectedId(service.id)}
                      className={`min-h-11 rounded-sm border px-4 py-2 text-xs font-semibold tracking-wide transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ${
                        isActive
                          ? 'border-accent bg-accent text-accent-ink'
                          : 'border-hairline bg-surface text-ink-secondary hover:border-accent-border hover:text-ink'
                      }`}
                    >
                      {service.name}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-10">
              <a
                href={buildWhatsAppUrl(activeService.whatsappMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-14 w-full sm:w-auto items-center justify-center gap-3 rounded-sm bg-accent px-8 py-4 text-sm font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <span>AGENDAR PELO WHATSAPP</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Vertical 4-Step Flow */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <ol className="divide-y divide-hairline rounded-sm border border-hairline bg-surface">
              {STEPS.map((step, index) => (
                <li
                  key={step.number}
                  className="flex items-start justify-between gap-6 p-6 sm:p-7"
                >
                  <div className="flex items-start gap-5">
                    <span className="font-display text-2xl font-bold text-accent-bright tabular-nums shrink-0">
                      {step.number}
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-bold uppercase tracking-wide text-ink sm:text-xl">
                        {step.title}
                      </h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-ink-secondary">
                        {step.detail}
                      </p>
                    </div>
                  </div>
                  {index < STEPS.length - 1 && (
                    <ArrowDown
                      className="mt-1 hidden h-4 w-4 shrink-0 text-ink-muted sm:block"
                      aria-hidden="true"
                    />
                  )}
                </li>
              ))}
            </ol>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
