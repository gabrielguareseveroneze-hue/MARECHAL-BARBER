import { motion } from 'motion/react';
import {
  CalendarCheck,
  Clock,
  Crosshair,
  Scissors,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { BARBERSHOP_INFO, DIFFERENTIALS } from '../data/barbershop';

const ICONS: Record<string, typeof Scissors> = {
  profissionais: Scissors,
  personalizados: Crosshair,
  horarios: Clock,
  ambiente: ShieldCheck,
  agendamento: CalendarCheck,
  experiencia: Sparkles,
};

export function DifferentialsSection() {
  return (
    <section className="border-b border-hairline bg-canvas py-24 sm:py-28 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="border-b border-hairline pb-8"
        >
          <h2
            className="max-w-3xl font-display font-bold uppercase tracking-tight text-ink"
            style={{
              fontSize: 'clamp(2.25rem, 4.4vw, 3.65rem)',
              lineHeight: 1.03,
              textWrap: 'balance',
            }}
          >
            POR QUE ESCOLHER A {BARBERSHOP_INFO.shortName.toUpperCase()}?
          </h2>
        </motion.div>

        {/* Varied-size 12-column Bento Grid (never uniform 3-card grid) */}
        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-12">
          {DIFFERENTIALS.map((item, idx) => {
            const IconComponent = ICONS[item.id] ?? Scissors;
            const isHighlighted = idx === 0 || idx === 3;

            return (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.55, delay: idx * 0.04, ease: [0.16, 1, 0.3, 1] }}
                className={`flex flex-col justify-between rounded-sm border p-7 sm:p-8 ${item.spanClass} ${
                  isHighlighted
                    ? 'border-accent-border/70 bg-surface-elevated'
                    : 'border-hairline bg-surface'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <IconComponent
                    className="h-5 w-5 text-accent shrink-0"
                    aria-hidden="true"
                  />
                  <span className="font-display text-sm font-semibold text-ink-muted tabular-nums">
                    0{idx + 1}
                  </span>
                </div>

                <div className="mt-10">
                  <h3 className="font-display text-xl font-bold uppercase tracking-wide text-ink sm:text-2xl">
                    {item.title}
                  </h3>
                  <p className="mt-3 max-w-xl text-sm leading-relaxed text-ink-secondary">
                    {item.description}
                  </p>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
