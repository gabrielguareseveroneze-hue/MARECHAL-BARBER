import { motion } from 'motion/react';
import { ArrowUpRight, Clock, MapPin, MessageCircle, Phone } from 'lucide-react';
import {
  BARBERSHOP_INFO,
  OPENING_HOURS,
  buildWhatsAppUrl,
} from '../data/barbershop';

export function LocationSection() {
  const whatsappHref = buildWhatsAppUrl();

  return (
    <section
      id="contato"
      className="border-b border-hairline bg-canvas py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Where We Are & Map Action */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <h2
              className="font-display font-bold uppercase tracking-tight text-ink"
              style={{
                fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
                lineHeight: 1.02,
              }}
            >
              ONDE ESTAMOS
            </h2>

            <div className="mt-10 space-y-6 border-t border-hairline pt-8">
              <div className="flex items-start gap-4">
                <MapPin className="mt-1 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-xs font-semibold tracking-wide uppercase text-ink-muted">
                    Endereço completo
                  </p>
                  <p className="mt-1 text-base leading-relaxed text-ink">
                    {BARBERSHOP_INFO.address}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="mt-1 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-xs font-semibold tracking-wide uppercase text-ink-muted">
                    Telefone
                  </p>
                  <a
                    href={`tel:+${BARBERSHOP_INFO.whatsappNumber}`}
                    className="mt-1 inline-block text-base font-medium text-ink tabular-nums transition-colors hover:text-accent-bright"
                  >
                    {BARBERSHOP_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MessageCircle className="mt-1 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-xs font-semibold tracking-wide uppercase text-ink-muted">
                    WhatsApp
                  </p>
                  <a
                    href={whatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 inline-block text-base font-medium text-ink tabular-nums transition-colors hover:text-accent-bright"
                  >
                    {BARBERSHOP_INFO.whatsappDisplay}
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={BARBERSHOP_INFO.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center gap-2 rounded-sm bg-accent px-6 py-3.5 text-xs font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <span>COMO CHEGAR</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>

              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 items-center gap-2 rounded-sm border border-accent-border bg-surface px-6 py-3.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap transition-colors duration-150 hover:bg-surface-elevated focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <span>FALAR NO WHATSAPP</span>
                <ArrowUpRight className="h-4 w-4 text-accent" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Opening Hours + Architectural Location Card */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col gap-6 lg:col-span-6"
          >
            <div className="rounded-sm border border-hairline bg-surface p-6 sm:p-8">
              <div className="flex items-center gap-3 border-b border-hairline pb-4">
                <Clock className="h-5 w-5 text-accent shrink-0" aria-hidden="true" />
                <h3 className="font-display text-2xl font-bold uppercase tracking-wide text-ink">
                  HORÁRIO DE FUNCIONAMENTO
                </h3>
              </div>

              <dl className="mt-4 divide-y divide-hairline">
                {OPENING_HOURS.map((item) => (
                  <div
                    key={item.day}
                    className="flex items-center justify-between gap-4 py-3 text-sm"
                  >
                    <dt className="font-semibold text-ink">{item.day}</dt>
                    <dd className="text-right text-ink-secondary tabular-nums">
                      {item.hours}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>

            {/* Clean static Map Direction Card */}
            <a
              href={BARBERSHOP_INFO.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between gap-4 rounded-sm border border-hairline bg-surface-elevated p-6 transition-colors duration-150 hover:border-accent-border"
            >
              <div>
                <p className="font-display text-lg font-bold uppercase tracking-wide text-ink">
                  Abrir rota no Google Maps
                </p>
                <p className="mt-1 text-xs text-ink-secondary">
                  {BARBERSHOP_INFO.address}
                </p>
              </div>
              <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-sm border border-hairline bg-canvas text-accent transition-colors group-hover:border-accent group-hover:bg-accent group-hover:text-accent-ink">
                <ArrowUpRight className="h-5 w-5" aria-hidden="true" />
              </span>
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
