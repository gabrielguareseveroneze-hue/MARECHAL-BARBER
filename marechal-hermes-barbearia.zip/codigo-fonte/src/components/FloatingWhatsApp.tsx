import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../data/barbershop';

export function FloatingWhatsApp() {
  return (
    <a
      href={buildWhatsAppUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar pelo WhatsApp"
      className="fixed right-5 bottom-5 z-50 inline-flex h-12 items-center gap-2.5 rounded-full border border-accent-border bg-accent px-5 text-xs font-bold tracking-wider uppercase text-accent-ink shadow-lg transition-transform duration-150 hover:scale-[1.03] hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
    >
      <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
      <span>WhatsApp</span>
    </a>
  );
}
