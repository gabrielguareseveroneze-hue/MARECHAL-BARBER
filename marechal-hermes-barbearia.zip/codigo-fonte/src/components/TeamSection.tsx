import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { BARBERSHOP_INFO, TEAM, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function TeamSection() {
  const [leadBarber, ...otherBarbers] = TEAM;

  return (
    <section
      id="profissionais"
      className="border-b border-hairline bg-surface py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-4 border-b border-hairline pb-8 sm:flex-row sm:items-end sm:justify-between"
        >
          <h2
            className="font-display font-bold uppercase tracking-tight text-ink"
            style={{
              fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
              lineHeight: 1.02,
            }}
          >
            NOSSO TIME
          </h2>
          <p className="max-w-md text-sm leading-relaxed text-ink-secondary sm:text-base">
            Especialistas dedicados a executar o corte e a barba ideais para o seu perfil.
          </p>
        </motion.div>

        {/* Varied Asymmetric Showcase: Lead Portrait Left (6 cols) + 2 Horizontal Stacked Cards Right (6 cols) */}
        <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* Featured Lead Barber */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="group flex flex-col overflow-hidden rounded-sm border border-hairline bg-canvas lg:col-span-6"
          >
            <div className="relative aspect-[4/4] sm:aspect-[4/3] lg:aspect-[5/5] w-full overflow-hidden bg-surface-elevated">
              <ResilientImage
                src={leadBarber.image}
                alt={leadBarber.imageAlt}
                className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-[1.03]"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/85 via-transparent to-transparent"
              />
            </div>

            <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
              <div>
                <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-ink sm:text-3xl">
                  {leadBarber.name}
                </h3>
                <p className="mt-1 text-sm font-semibold text-accent-bright">
                  {leadBarber.role}
                </p>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary sm:text-base">
                  {leadBarber.bio}
                </p>
              </div>

              <div className="mt-8">
                <a
                  href={buildWhatsAppUrl(
                    `Olá! Gostaria de agendar um horário com ${leadBarber.name} (${leadBarber.role}) na ${BARBERSHOP_INFO.name}.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-12 w-full sm:w-auto items-center justify-center gap-2 rounded-sm bg-accent px-6 py-3 text-xs font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>{leadBarber.ctaLabel}</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>

          {/* Stacked Pair of Barbers */}
          <div className="flex flex-col gap-8 lg:col-span-6">
            {otherBarbers.map((barber, idx) => (
              <motion.article
                key={barber.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.6, delay: (idx + 1) * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="group grid flex-1 grid-cols-1 overflow-hidden rounded-sm border border-hairline bg-canvas sm:grid-cols-12"
              >
                <div className="relative aspect-[3/4] sm:aspect-auto sm:col-span-5 overflow-hidden bg-surface-elevated">
                  <ResilientImage
                    src={barber.image}
                    alt={barber.imageAlt}
                    className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                  />
                </div>

                <div className="flex flex-col justify-between p-6 sm:col-span-7 sm:p-7">
                  <div>
                    <h3 className="font-display text-xl font-bold uppercase tracking-tight text-ink sm:text-2xl">
                      {barber.name}
                    </h3>
                    <p className="mt-1 text-xs font-semibold text-accent-bright sm:text-sm">
                      {barber.role}
                    </p>
                    <p className="mt-4 text-sm leading-relaxed text-ink-secondary">
                      {barber.bio}
                    </p>
                  </div>

                  <div className="mt-6">
                    <a
                      href={buildWhatsAppUrl(
                        `Olá! Gostaria de agendar um horário com ${barber.name} (${barber.role}) na ${BARBERSHOP_INFO.name}.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-accent-border bg-surface px-4 py-2.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap transition-colors duration-150 hover:bg-accent hover:text-accent-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                    >
                      <span>{barber.ctaLabel}</span>
                      <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
