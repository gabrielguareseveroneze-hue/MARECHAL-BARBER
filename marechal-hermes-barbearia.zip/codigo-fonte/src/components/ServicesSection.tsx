import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { SERVICES, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function ServicesSection() {
  const [corte, corteBarba, barba, premium, infantil, acabamento] = SERVICES;

  return (
    <section
      id="servicos"
      className="border-b border-hairline bg-surface py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        {/* Heading without eyebrow, strong size/weight contrast */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-4 border-b border-hairline pb-8 sm:flex-row sm:items-end sm:justify-between"
        >
          <h2
            className="font-display font-bold uppercase tracking-tight text-ink"
            style={{
              fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
              lineHeight: 1.02,
            }}
          >
            NOSSOS SERVIÇOS
          </h2>
          <p className="max-w-md text-sm font-normal leading-relaxed text-ink-secondary sm:text-base">
            Tudo para você sair daqui com o visual em dia.
          </p>
        </motion.div>

        {/* Varied-size asymmetric Bento Grid */}
        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Card 1 (7 cols): Corte Masculino */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="group flex flex-col overflow-hidden rounded-sm border border-hairline bg-canvas lg:col-span-7"
          >
            {corte.image && (
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={corte.image}
                  alt={corte.imageAlt || corte.name}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
            )}
            <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
              <div>
                <div className="flex items-baseline justify-between gap-4 border-b border-hairline pb-4">
                  <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-ink sm:text-3xl">
                    {corte.name}
                  </h3>
                  <span className="font-display text-2xl font-bold text-accent-bright tabular-nums whitespace-nowrap shrink-0">
                    {corte.priceFormatted}
                  </span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary sm:text-base">
                  {corte.description}
                </p>
              </div>
              <div className="mt-8 flex items-center justify-between gap-4">
                <span className="text-xs font-medium text-ink-muted tabular-nums">
                  Duração aproximada: {corte.duration}
                </span>
                <a
                  href={buildWhatsAppUrl(corte.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm bg-accent px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>

          {/* Card 2 (5 cols): Corte + Barba */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.55, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="group flex flex-col overflow-hidden rounded-sm border border-hairline bg-canvas lg:col-span-5"
          >
            {corteBarba.image && (
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={corteBarba.image}
                  alt={corteBarba.imageAlt || corteBarba.name}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
            )}
            <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
              <div>
                <div className="flex items-baseline justify-between gap-4 border-b border-hairline pb-4">
                  <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-ink">
                    {corteBarba.name}
                  </h3>
                  <span className="font-display text-lg font-semibold text-accent-bright tabular-nums whitespace-nowrap shrink-0">
                    {corteBarba.priceFormatted}
                  </span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary">
                  {corteBarba.description}
                </p>
              </div>
              <div className="mt-8 flex items-center justify-between gap-4">
                <span className="text-xs font-medium text-ink-muted tabular-nums">
                  Duração: {corteBarba.duration}
                </span>
                <a
                  href={buildWhatsAppUrl(corteBarba.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-accent-border bg-surface px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent hover:text-accent-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>

          {/* Card 3 (5 cols): Barba */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="group flex flex-col overflow-hidden rounded-sm border border-hairline bg-canvas lg:col-span-5"
          >
            {barba.image && (
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={barba.image}
                  alt={barba.imageAlt || barba.name}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
            )}
            <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
              <div>
                <div className="flex items-baseline justify-between gap-4 border-b border-hairline pb-4">
                  <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-ink">
                    {barba.name}
                  </h3>
                  <span className="font-display text-2xl font-bold text-accent-bright tabular-nums whitespace-nowrap shrink-0">
                    {barba.priceFormatted}
                  </span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary">
                  {barba.description}
                </p>
              </div>
              <div className="mt-8 flex items-center justify-between gap-4">
                <span className="text-xs font-medium text-ink-muted tabular-nums">
                  Duração: {barba.duration}
                </span>
                <a
                  href={buildWhatsAppUrl(barba.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-accent-border bg-surface px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent hover:text-accent-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>

          {/* Card 4 (7 cols): Experiência Premium */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.55, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="group flex flex-col overflow-hidden rounded-sm border border-hairline bg-canvas lg:col-span-7"
          >
            {premium.image && (
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-surface-elevated">
                <ResilientImage
                  src={premium.image}
                  alt={premium.imageAlt || premium.name}
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              </div>
            )}
            <div className="flex flex-1 flex-col justify-between p-6 sm:p-8">
              <div>
                <div className="flex items-baseline justify-between gap-4 border-b border-hairline pb-4">
                  <h3 className="font-display text-2xl font-bold uppercase tracking-tight text-ink sm:text-3xl">
                    {premium.name}
                  </h3>
                  <span className="font-display text-2xl font-bold text-accent-bright tabular-nums whitespace-nowrap shrink-0">
                    {premium.priceFormatted}
                  </span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary sm:text-base">
                  {premium.description}
                </p>
              </div>
              <div className="mt-8 flex items-center justify-between gap-4">
                <span className="text-xs font-medium text-ink-muted tabular-nums">
                  Duração aproximada: {premium.duration}
                </span>
                <a
                  href={buildWhatsAppUrl(premium.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm bg-accent px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.article>

          {/* Compact Asymmetric Row: Corte Infantil (6 cols) & Acabamento (6 cols) */}
          {[infantil, acabamento].map((service, idx) => (
            <motion.article
              key={service.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.55, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col justify-between rounded-sm border border-hairline bg-canvas p-6 sm:p-8 lg:col-span-6"
            >
              <div>
                <div className="flex items-baseline justify-between gap-4 border-b border-hairline pb-4">
                  <h3 className="font-display text-xl font-bold uppercase tracking-tight text-ink sm:text-2xl">
                    {service.name}
                  </h3>
                  <span className="font-display text-lg font-semibold text-accent-bright tabular-nums whitespace-nowrap shrink-0">
                    {service.priceFormatted}
                  </span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-secondary">
                  {service.description}
                </p>
              </div>

              <div className="mt-8 flex items-center justify-between gap-4">
                <span className="text-xs font-medium text-ink-muted tabular-nums">
                  Duração aproximada: {service.duration}
                </span>
                <a
                  href={buildWhatsAppUrl(service.whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-accent-border bg-surface px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent hover:text-accent-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
