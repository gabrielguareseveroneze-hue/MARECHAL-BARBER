import { motion } from 'motion/react';
import { ArrowDownRight, ArrowUpRight, MapPin } from 'lucide-react';
import { BARBERSHOP_INFO, HERO_MEDIA, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function Hero() {
  const whatsappHref = buildWhatsAppUrl();

  return (
    <section
      id="inicio"
      className="relative overflow-hidden border-b border-hairline bg-canvas pt-10 pb-16 sm:pt-14 sm:pb-24 lg:min-h-[calc(100svh-4rem)] lg:flex lg:items-center lg:py-16"
    >
      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: Strictly left-aligned asymmetric editorial text (NO eyebrow) */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between text-left lg:col-span-6 lg:py-4"
          >
            <div>
              <h1
                className="font-display font-bold uppercase tracking-tight text-ink"
                style={{
                  fontSize: 'clamp(3.25rem, 6.2vw, 5.5rem)',
                  lineHeight: 0.98,
                  textWrap: 'balance',
                }}
              >
                SEU ESTILO{' '}
                <span className="block text-gradient-orange">COMEÇA AQUI.</span>
              </h1>

              <p className="mt-7 max-w-lg text-base font-normal leading-relaxed text-ink-secondary sm:text-lg">
                Cortes de precisão, barba impecável e uma experiência feita para você.
              </p>

              <div className="mt-10 flex flex-wrap items-center gap-4 sm:gap-5">
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-12 items-center gap-2.5 rounded-sm bg-accent px-7 py-3.5 text-sm font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>AGENDAR HORÁRIO</span>
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>

                <a
                  href="#servicos"
                  className="inline-flex min-h-12 items-center gap-2 rounded-sm border border-ink/30 bg-ink px-6 py-3.5 text-sm font-bold tracking-wider uppercase text-canvas whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-ink-secondary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <span>CONHECER SERVIÇOS</span>
                  <ArrowDownRight className="h-4 w-4 text-accent-hover" aria-hidden="true" />
                </a>
              </div>
            </div>

            <div className="mt-12 flex items-center gap-2.5 border-t border-hairline pt-6 text-xs sm:text-sm font-medium text-ink-secondary">
              <MapPin className="h-4 w-4 text-accent shrink-0" aria-hidden="true" />
              <span>
                {BARBERSHOP_INFO.name} · {BARBERSHOP_INFO.cityState}
              </span>
            </div>
          </motion.div>

          {/* Right Column: Large asymmetric barbershop image */}
          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[300px] sm:min-h-[420px] lg:min-h-[540px] overflow-hidden rounded-sm border border-hairline bg-surface">
              <ResilientImage
                src={HERO_MEDIA.image}
                alt={HERO_MEDIA.alt}
                loading="eager"
                fetchPriority="high"
                animateOnView={true}
                className="h-full w-full object-cover object-center"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/80 via-canvas/10 to-transparent"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
