import { motion } from 'motion/react';
import { ABOUT_MEDIA, BARBERSHOP_INFO, STATS } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function AboutSection() {
  return (
    <section
      id="barbearia"
      className="border-b border-hairline bg-surface py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Editorial Barbershop Craftsmanship Photo */}
          <div className="lg:col-span-5">
            <div className="relative aspect-[4/5] overflow-hidden rounded-sm border border-hairline bg-surface-elevated">
              <ResilientImage
                src={ABOUT_MEDIA.image}
                alt={ABOUT_MEDIA.alt}
                className="h-full w-full object-cover object-center"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/75 via-transparent to-transparent"
              />
            </div>
          </div>

          {/* Right Column: Institutional Copy & 4 Visual Stats */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:gap-6">
              <img
                src={BARBERSHOP_INFO.logo}
                alt={`Emblema ${BARBERSHOP_INFO.name}`}
                className="h-20 w-20 rounded-sm border border-accent-border/60 object-cover shrink-0"
              />
              <h2
                className="font-display font-bold uppercase tracking-tight text-ink"
                style={{
                  fontSize: 'clamp(2.25rem, 4.4vw, 3.65rem)',
                  lineHeight: 1.03,
                  textWrap: 'balance',
                }}
              >
                MAIS QUE UM CORTE. UMA EXPERIÊNCIA.
              </h2>
            </div>

            <p className="mt-6 max-w-2xl text-base font-medium leading-relaxed text-ink sm:text-lg">
              Na {BARBERSHOP_INFO.name}, acreditamos que cuidar do visual também é cuidar de você.
            </p>

            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-ink-secondary sm:text-base">
              Cada atendimento nasce da união entre qualidade técnica, profissionais qualificados e respeito absoluto à pontualidade. Em um ambiente confortável e bem preparado, entregamos estilo sob medida e uma experiência pensada do início ao fim para o homem contemporâneo.
            </p>

            {/* Hairline-divided 2x2 stats grid */}
            <dl className="mt-12 grid grid-cols-2 border-t border-hairline">
              {STATS.map((stat, index) => (
                <div
                  key={stat.label}
                  className={`py-7 ${
                    index % 2 === 0 ? 'border-r border-hairline pr-6' : 'pl-6 sm:pl-10'
                  } ${index < 2 ? 'border-b border-hairline' : ''}`}
                >
                  <dt className="text-xs sm:text-sm font-medium text-ink-secondary">
                    {stat.label}
                  </dt>
                  <dd className="mt-2 font-display text-3xl font-bold text-accent-bright tabular-nums sm:text-4xl lg:text-5xl">
                    {stat.value}
                  </dd>
                </div>
              ))}
            </dl>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
