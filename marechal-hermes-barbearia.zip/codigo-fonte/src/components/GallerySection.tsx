import { motion } from 'motion/react';
import { GALLERY_ITEMS } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function GallerySection() {
  return (
    <section
      id="galeria"
      className="border-b border-hairline bg-canvas py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-4 border-b border-hairline pb-8 sm:flex-row sm:items-end sm:justify-between"
        >
          <h2
            className="font-display font-bold uppercase tracking-tight text-ink"
            style={{
              fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
              lineHeight: 1.02,
            }}
          >
            NOSSO TRABALHO
          </h2>
          <p className="max-w-md text-sm leading-relaxed text-ink-secondary sm:text-base">
            Cortes, barbas, degradês e detalhes do ambiente que traduzem nosso padrão de entrega.
          </p>
        </motion.div>

        {/* Responsive Asymmetric Bento Gallery */}
        <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-12">
          {GALLERY_ITEMS.map((item) => (
            <figure
              key={item.id}
              className={`group relative overflow-hidden rounded-sm border border-hairline bg-surface ${item.spanClass}`}
            >
              <ResilientImage
                src={item.src}
                alt={item.alt}
                className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/85 via-canvas/10 to-transparent opacity-80 transition-opacity duration-300 group-hover:opacity-95"
              />
              <figcaption className="absolute bottom-4 left-4 right-4 text-xs font-semibold tracking-wide text-ink sm:text-sm">
                {item.caption}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
