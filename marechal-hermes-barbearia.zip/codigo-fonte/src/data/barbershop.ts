export interface BarberService {
  id: 'corte' | 'barba' | 'corte-barba' | 'infantil' | 'acabamento' | 'premium';
  index: string;
  name: string;
  priceFormatted: string;
  duration: string;
  description: string;
  whatsappMessage: string;
  image?: string;
  imageAlt?: string;
}

export interface BarberStat {
  value: string;
  label: string;
}

export interface BarberProfessional {
  id: string;
  name: string;
  role: string;
  specialty: string;
  bio: string;
  image: string;
  imageAlt: string;
  ctaLabel: string;
}

export interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  caption: string;
  spanClass: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  context: string;
}

export interface OpeningHour {
  day: string;
  hours: string;
}

export interface DifferentialItem {
  id: string;
  title: string;
  description: string;
  spanClass: string;
}

// Dados principais editáveis da barbearia
export const BARBERSHOP_INFO = {
  name: 'Marechal Hermes Barbearia',
  shortName: 'Marechal Hermes',
  logo: '/assets/aistudio/image_881f7106.png',
  cityState: 'Araguaína, TO',
  address: 'Av. José de Brito, 718, St. Anhanguera, Araguaína, TO, 77818-530',
  phoneDisplay: '(63) 99250-8341',
  whatsappDisplay: '(63) 99250-8341',
  whatsappNumber: '5563992508341',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=Av.+Jos%C3%A9+de+Brito%2C+718+-+St.+Anhanguera%2C+Aragua%C3%ADna+-+TO%2C+77818-530',
  social: {
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
    tiktok: 'https://www.tiktok.com/',
  },
} as const;

export function buildWhatsAppUrl(message?: string): string {
  const defaultMsg = `Olá! Vim pelo site e gostaria de agendar um horário na ${BARBERSHOP_INFO.name}.`;
  const text = encodeURIComponent(message?.trim() || defaultMsg);
  return `https://wa.me/${BARBERSHOP_INFO.whatsappNumber}?text=${text}`;
}

export const HERO_MEDIA = {
  image: '/src/assets/images/hero_barbershop_1794944205698.jpg',
  alt: 'Ambiente interno da Marechal Hermes Barbearia com atendimento masculino de precisão',
} as const;

export const ABOUT_MEDIA = {
  image: '/src/assets/images/barbershop_tools_detail_1794944587644.jpg',
  alt: 'Bancada profissional da Marechal Hermes Barbearia com tesouras de precisão e navalha clássica',
} as const;

export const FINAL_CTA_MEDIA = {
  image: '/src/assets/images/barber_fade_work_1794944586020.jpg',
  alt: 'Barbeiro executando acabamento degradê com precisão em ambiente escuro sofisticado',
} as const;

// Serviços editáveis
export const SERVICES: BarberService[] = [
  {
    id: 'corte',
    index: '01',
    name: 'Corte Masculino',
    priceFormatted: 'R$ 60',
    duration: '45 min',
    description:
      'Cortes modernos, clássicos ou personalizados de acordo com seu estilo e formato de rosto.',
    whatsappMessage: `Olá! Gostaria de agendar um Corte Masculino na ${BARBERSHOP_INFO.name}.`,
    image: '/src/assets/images/service_haircut_1794944207377.jpg',
    imageAlt: 'Barbeiro executando corte masculino na tesoura com acabamento limpo',
  },
  {
    id: 'corte-barba',
    index: '02',
    name: 'Corte + Barba',
    priceFormatted: 'Sob consulta',
    duration: '75 min',
    description:
      'A combinação completa para renovar o visual com alinhamento de corte, barba e finalização.',
    whatsappMessage: `Olá! Gostaria de agendar Corte + Barba na ${BARBERSHOP_INFO.name}.`,
    image: '/src/assets/images/barber_fade_work_1794944586020.jpg',
    imageAlt: 'Execução de corte degradê combinado com alinhamento completo de barba',
  },
  {
    id: 'barba',
    index: '03',
    name: 'Barba',
    priceFormatted: 'R$ 45',
    duration: '35 min',
    description:
      'Modelagem, acabamento na navalha, toalha quente e cuidados para uma barba impecável.',
    whatsappMessage: `Olá! Vim pelo site e gostaria de agendar um serviço de Barba na ${BARBERSHOP_INFO.name}.`,
    image: '/src/assets/images/service_beard_1794944208562.jpg',
    imageAlt: 'Ritual tradicional de modelagem de barba com toalha quente e navalha',
  },
  {
    id: 'premium',
    index: '04',
    name: 'Experiência Premium',
    priceFormatted: 'R$ 80',
    duration: '60 min',
    description:
      'Atendimento completo com tratamento capilar revitalizante para quem busca uma experiência diferenciada.',
    whatsappMessage: `Olá! Gostaria de agendar a Experiência Premium na ${BARBERSHOP_INFO.name}.`,
    image: '/src/assets/images/service_treatment_1794944209295.jpg',
    imageAlt: 'Tratamento capilar e revitalização no lavatório clássico da barbearia',
  },
  {
    id: 'infantil',
    index: '05',
    name: 'Corte Infantil',
    priceFormatted: 'Sob consulta',
    duration: '35 min',
    description:
      'Atendimento especializado, paciente e confortável para crianças de todas as idades.',
    whatsappMessage: `Olá! Gostaria de agendar um Corte Infantil na ${BARBERSHOP_INFO.name}.`,
  },
  {
    id: 'acabamento',
    index: '06',
    name: 'Acabamento',
    priceFormatted: 'Sob consulta',
    duration: '20 min',
    description:
      'Pezinho, contorno de nuca, alinhamento das laterais e finalização precisa entre cortes.',
    whatsappMessage: `Olá! Gostaria de agendar um Acabamento na ${BARBERSHOP_INFO.name}.`,
  },
];

// Estatísticas editáveis da barbearia
export const STATS: BarberStat[] = [
  { value: '+10.000', label: 'Clientes atendidos' },
  { value: '+15', label: 'Anos de experiência' },
  { value: '4,9', label: 'Avaliação média' },
  { value: '100%', label: 'Dedicação ao cliente' },
];

// Profissionais (substitua pelos nomes reais quando desejar)
export const TEAM: BarberProfessional[] = [
  {
    id: 'barbeiro-1',
    name: 'Barbeiro Especialista 01',
    role: 'Cortes Modernos e Degradês',
    specialty: 'Visagismo e Fade de Precisão',
    bio: 'Especialista em degradês limpos, cortes estruturados na tesoura e consultoria de estilo conforme o perfil do cliente.',
    image: '/src/assets/images/gallery_craftsmanship_1794944210018.jpg',
    imageAlt: 'Barbeiro especialista em cortes modernos e degradês na Marechal Hermes Barbearia',
    ctaLabel: 'AGENDAR COM ESTE PROFISSIONAL',
  },
  {
    id: 'barbeiro-2',
    name: 'Barbeiro Especialista 02',
    role: 'Cortes Urbanos e Acabamento',
    specialty: 'Tesoura, Máquina e Contornos',
    bio: 'Domínio técnico em transições suaves, linhas nítidas e finalização natural para o dia a dia.',
    image: '/src/assets/images/barber_portrait_two_1794944586869.jpg',
    imageAlt: 'Barbeiro especialista em cortes urbanos e acabamento fino',
    ctaLabel: 'AGENDAR COM ESTE PROFISSIONAL',
  },
  {
    id: 'barbeiro-3',
    name: 'Barbeiro Especialista 03',
    role: 'Barba Clássica e Navalha',
    specialty: 'Barboterapia e Cortes Tradicionais',
    bio: 'Focado em alinhamento anatômico de barba, ritual de toalha quente e cortes executivos atemporais.',
    image: '/src/assets/images/barber_portrait_three_1794944586159.jpg',
    imageAlt: 'Barbeiro especialista em barba clássica e atendimento executivo',
    ctaLabel: 'AGENDAR COM ESTE PROFISSIONAL',
  },
];

// Galeria de trabalhos e ambiente
export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    src: '/src/assets/images/service_haircut_1794944207377.jpg',
    alt: 'Corte masculino na tesoura com acabamento preciso',
    caption: 'Precisão na tesoura e simetria',
    spanClass: 'md:col-span-7 md:row-span-2 aspect-[16/10] md:aspect-auto md:min-h-[420px]',
  },
  {
    id: 'gal-2',
    src: '/src/assets/images/barber_fade_work_1794944586020.jpg',
    alt: 'Degradê limpo executado com máquina de acabamento',
    caption: 'Degradê e transição suave',
    spanClass: 'md:col-span-5 aspect-[4/3]',
  },
  {
    id: 'gal-3',
    src: '/src/assets/images/service_beard_1794944208562.jpg',
    alt: 'Barba modelada com toalha quente e navalha',
    caption: 'Ritual de barba e toalha quente',
    spanClass: 'md:col-span-5 aspect-[4/3]',
  },
  {
    id: 'gal-4',
    src: '/src/assets/images/barbershop_tools_detail_1794944587644.jpg',
    alt: 'Ferramentas profissionais higienizadas na bancada escura',
    caption: 'Instrumentos esterilizados e cuidados dedicados',
    spanClass: 'md:col-span-6 aspect-[16/10]',
  },
  {
    id: 'gal-5',
    src: '/src/assets/images/service_treatment_1794944209295.jpg',
    alt: 'Tratamento capilar relaxante no lavatório da barbearia',
    caption: 'Cuidado capilar e relaxamento',
    spanClass: 'md:col-span-3 aspect-[4/3] md:aspect-auto',
  },
  {
    id: 'gal-6',
    src: '/src/assets/images/hero_barbershop_1794944205698.jpg',
    alt: 'Salão principal da Marechal Hermes Barbearia',
    caption: 'Nosso espaço em Araguaína',
    spanClass: 'md:col-span-3 aspect-[4/3] md:aspect-auto',
  },
];

// Avaliações demonstrativas editáveis
export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'rev-1',
    quote:
      'Excelente atendimento, ambiente incrível e corte impecável. Pontualidade do começo ao fim, sem dúvida uma experiência diferenciada.',
    author: 'Cliente verificado',
    context: 'Corte Masculino e Barba',
  },
  {
    id: 'rev-2',
    quote:
      'Barbeiros atentos aos detalhes e ambiente muito bem cuidado. O agendamento pelo WhatsApp torna tudo rápido e organizado.',
    author: 'Cliente verificado',
    context: 'Experiência Premium',
  },
  {
    id: 'rev-3',
    quote:
      'Degradê limpo e acabamento preciso na navalha. Recomendo para quem valoriza qualidade e respeito ao horário marcado.',
    author: 'Cliente verificado',
    context: 'Corte Masculino',
  },
];

// Diferenciais em grid assimétrico variado
export const DIFFERENTIALS: DifferentialItem[] = [
  {
    id: 'profissionais',
    title: 'Profissionais qualificados',
    description:
      'Barbeiros experientes em constante atualização técnica para executar estilos clássicos e contemporâneos com segurança.',
    spanClass: 'md:col-span-7',
  },
  {
    id: 'personalizados',
    title: 'Cortes personalizados',
    description:
      'Análise de visagismo, textura e rotina para entregar um corte que valoriza seus traços.',
    spanClass: 'md:col-span-5',
  },
  {
    id: 'horarios',
    title: 'Horários organizados',
    description:
      'Respeito rigoroso ao seu tempo com atendimento planejado e sem longas esperas.',
    spanClass: 'md:col-span-4',
  },
  {
    id: 'ambiente',
    title: 'Ambiente confortável e higienizado',
    description:
      'Estações esterilizadas a cada atendimento, climatização agradável e espaço pensado para o bem-estar masculino.',
    spanClass: 'md:col-span-8',
  },
  {
    id: 'agendamento',
    title: 'Agendamento fácil',
    description:
      'Contato direto pelo WhatsApp para escolher o serviço e confirmar seu horário em poucos instantes.',
    spanClass: 'md:col-span-6',
  },
  {
    id: 'experiencia',
    title: 'Foco na experiência do cliente',
    description:
      'Cada detalhe do atendimento existe para que você saia confiante e com o visual em dia.',
    spanClass: 'md:col-span-6',
  },
];

// Horários editáveis (sem inventar horários não informados)
export const OPENING_HOURS: OpeningHour[] = [
  { day: 'Segunda', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Terça', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Quarta', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Quinta', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Sexta', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Sábado', hours: 'Sob agendamento (consulte no WhatsApp)' },
  { day: 'Domingo', hours: 'Consulte disponibilidade' },
];
