import { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { BARBERSHOP_INFO, buildWhatsAppUrl } from '../data/barbershop';

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#barbearia', label: 'Barbearia' },
  { href: '#profissionais', label: 'Profissionais' },
  { href: '#avaliacoes', label: 'Avaliações' },
  { href: '#contato', label: 'Contato' },
] as const;

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const whatsappHref = buildWhatsAppUrl();

  return (
    <header className="sticky top-0 z-40 border-b border-hairline bg-canvas/94 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-5 sm:px-8 lg:px-12">
        {/* Zone 1: Brand Logo */}
        <a
          href="#inicio"
          className="inline-flex items-center gap-3 font-display text-lg sm:text-xl font-bold tracking-wider uppercase text-ink whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent"
        >
          <img
            src={BARBERSHOP_INFO.logo}
            alt={`Logo ${BARBERSHOP_INFO.name}`}
            className="h-10 w-10 rounded-sm border border-hairline object-cover shrink-0"
          />
          <span>{BARBERSHOP_INFO.shortName}</span>
        </a>

        {/* Zone 2: Navigation links */}
        <nav
          aria-label="Navegação principal"
          className="hidden lg:flex items-center gap-7 text-sm font-medium text-ink-secondary"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-ink after:absolute after:bottom-0 after:left-0 after:h-px after:w-0 after:bg-accent after:transition-all after:duration-200 hover:after:w-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Highlighted CTA + mobile menu toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 rounded-sm bg-accent px-4 py-2.5 text-xs font-bold tracking-wider uppercase text-accent-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            <span>AGENDAR AGORA</span>
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex lg:hidden h-11 w-11 items-center justify-center rounded-sm border border-hairline text-ink transition-colors hover:border-accent-border hover:bg-surface focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-hairline bg-surface px-5 py-6">
          <nav aria-label="Menu móvel" className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center text-base font-medium text-ink-secondary transition-colors hover:text-ink"
              >
                {link.label}
              </a>
            ))}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="mt-4 inline-flex min-h-12 items-center justify-center gap-2 rounded-sm bg-accent px-5 py-3 text-sm font-bold tracking-wider uppercase text-accent-ink transition-colors hover:bg-accent-hover"
            >
              <span>AGENDAR AGORA</span>
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
