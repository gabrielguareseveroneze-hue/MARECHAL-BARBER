import { motion } from 'motion/react';
import { ArrowUpRight, Star } from 'lucide-react';
import { BARBERSHOP_INFO, TESTIMONIALS } from '../data/barbershop';

export function TestimonialsSection() {
  const [featured, ...secondary] = TESTIMONIALS;

  return (
    <section
      id="avaliacoes"
      className="border-b border-hairline bg-surface py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col gap-6 border-b border-hairline pb-8 sm:flex-row sm:items-end sm:justify-between"
        >
          <h2
            className="max-w-2xl font-display font-bold uppercase tracking-tight text-ink"
            style={{
              fontSize: 'clamp(2.25rem, 4.5vw, 3.75rem)',
              lineHeight: 1.02,
              textWrap: 'balance',
            }}
          >
            QUEM PASSA POR AQUI, APROVA.
          </h2>

          <a
            href={BARBERSHOP_INFO.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-11 items-center gap-2 rounded-sm border border-accent-border bg-canvas px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-ink whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-accent hover:text-accent-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            <span>VER MAIS AVALIAÇÕES</span>
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
        </motion.div>

        {/* Varied Asymmetric Layout: 1 Wide Lead Quote (7 cols) + 2 Stacked Quotes (5 cols) */}
        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-12">
          <motion.blockquote
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between rounded-sm border border-accent-border/60 bg-canvas p-8 sm:p-10 lg:col-span-7"
          >
            <div>
              <div className="flex items-center gap-1 text-accent-bright" aria-label="Avaliação 5 de 5 estrelas">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" aria-hidden="true" />
                ))}
              </div>
              <p className="mt-8 font-display text-2xl font-semibold leading-snug text-ink sm:text-3xl">
                "{featured.quote}"
              </p>
            </div>

            <footer className="mt-10 flex items-center justify-between border-t border-hairline pt-5 text-sm">
              <span className="font-semibold text-ink">{featured.author}</span>
              <span className="text-ink-secondary">{featured.context}</span>
            </footer>
          </motion.blockquote>

          <div className="flex flex-col gap-6 lg:col-span-5">
            {secondary.map((review, idx) => (
              <motion.blockquote
                key={review.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.6, delay: (idx + 1) * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="flex flex-1 flex-col justify-between rounded-sm border border-hairline bg-canvas p-6 sm:p-8"
              >
                <div>
                  <div className="flex items-center gap-1 text-accent-bright" aria-label="Avaliação 5 de 5 estrelas">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                    ))}
                  </div>
                  <p className="mt-5 text-base font-medium leading-relaxed text-ink">
                    "{review.quote}"
                  </p>
                </div>

                <footer className="mt-6 flex items-center justify-between border-t border-hairline pt-4 text-xs sm:text-sm">
                  <span className="font-semibold text-ink">{review.author}</span>
                  <span className="text-ink-secondary">{review.context}</span>
                </footer>
              </motion.blockquote>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
